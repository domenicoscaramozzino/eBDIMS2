#!/bin/bash

./eBDIMS2_pipeline_par.sh "6pof" "ABCD" 1000 99.9 0.8

#Parameters to insert:

#1.PDB ID reference,
#2.Chain(s) ID reference,
#3.Frequency of frame output writing,
#4.DIMS convergence stop criterion (%),
#5.RMSD convergence stop criterion (Å)